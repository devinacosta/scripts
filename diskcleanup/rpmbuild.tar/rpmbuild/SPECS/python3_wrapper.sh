#!/bin/bash
exec /usr/bin/python3 "$@"
